//
//  SecondViewController.swift
//  NotificationCenter
//
//  Created by Nick Nguyen on 3/6/20.
//  Copyright © 2020 Nick Nguyen. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func fireNotification(_ sender: UIButton ) {
        
        var dict: Dictionary<String,AnyObject> = Dictionary()
        dict.updateValue("Bell has rung" as AnyObject, forKey: "DATE")
        
        
        NotificationCenter.default.post(name: Notification.Name(rawValue: "FIRENOTIFICATION"), object: nil, userInfo: dict)
        _ = self.navigationController?.popViewController(animated: true)
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
