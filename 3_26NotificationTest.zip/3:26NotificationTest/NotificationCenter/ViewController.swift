//
//  ViewController.swift
//  NotificationCenter
//
//  Created by Nick Nguyen on 3/6/20.
//  Copyright © 2020 Nick Nguyen. All rights reserved.
//

import UIKit


class ViewController: UIViewController {

    
    @IBOutlet weak var titleLabel: UILabel!
  
    @IBAction func buttonTapped(_ sender: UIButton) {
        let secondVC = self.storyboard?.instantiateViewController(withIdentifier: "SecondViewController") as! SecondViewController
              self.navigationController?.pushViewController(secondVC, animated: true)
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.titleLabel.text = ""
   
        NotificationCenter.default.addObserver(self, selector: #selector(notificationFired), name: NSNotification.Name(rawValue: "FIRENOTIFICATION"), object: nil)
    }

    @objc func notificationFired(_ notification: Notification) {
        let userInfo = notification.userInfo
        
        if let date = userInfo?["DATE"] as? String {
            self.titleLabel.text = date
        }
    }
}

